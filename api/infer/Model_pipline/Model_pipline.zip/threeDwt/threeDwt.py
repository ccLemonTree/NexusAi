# -*- coding: utf-8 -*-
# 人脸
import os
import time

import cv2
import requests
import json
import uuid
from Utils.boundingbox import BoundingBox
from running import analyseRun
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.config import cfg
from Utils.utils import compare_images

class Model(ModelClass):

    # 3d 调用 接口
    def http_post_threeD(self, picture_info, snap):
        # req_list = [grequests.post("127.0.0.1:8500",json = {},timeout=60)]
        self.session = requests.session()
        response_dicts = {}
        response_dicts['code'] = -1

        try:

            for i in range(self.cfg3d['resend']):
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capurlIp']}:{8000 + int(snap)}/{self.cfg3d['3d_capurl']}",
                    data=picture_info, timeout=60)
                response_dicts = response_dicts.json()
                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
        except Exception as e:
            print(e)
            print(e.__traceback__.tb_lineno)
            print(e.__traceback__.tb_frame.f_globals["__file__"])

        finally:
            self.session.close()
            return response_dicts

    def triplicate(self, savepath):
        flag = True
        for suffix in ['.jpeg', '_2.jpeg', '.json']:

            if os.path.isfile(savepath + suffix) == False:
                flag = False
        return flag

    def del_file(self, path):
        if os.path.isfile(path):
            os.remove(path)

    def http_threeD_orign(self, deviceID, preset, snap):
        close_data = {
            'deviceID': deviceID,
            'preset': str(preset),
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'close'
        }
        self.session = requests.session()
        response_dicts = {}
        for i in range(1):
            try:
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capcloseIp']}:{8000 + int(snap)}/api/goto/preset",
                    data=close_data, timeout=60)
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 回归阈值为')
                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
            except Exception as e:
                print(e)
                print(e.__traceback__.tb_lineno)
                print(e.__traceback__.tb_frame.f_globals["__file__"])

            finally:
                self.session.close()
                return response_dicts

    def http_threeD_close(self, deviceID, preset, snap):
        close_data = {
            'deviceID': deviceID,
            'preset': str(preset),
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'close'
        }
        self.session = requests.session()
        response_dicts = {}
        for i in range(1):
            try:
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 准备释放设备 http://{self.cfg3d["3d_capcloseIp"]}:{8000 + int(snap)}/{self.cfg3d["3d_capcloseUrl"]}')
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capcloseIp']}:{8000 + int(snap)}/{self.cfg3d['3d_capcloseUrl']}",
                    data=close_data, timeout=60)
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 释放3d设备成功')

                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
            except Exception as e:
                print(e)
                print(e.__traceback__.tb_lineno)
                print(e.__traceback__.tb_frame.f_globals["__file__"])

            finally:
                self.session.close()
                return response_dicts

    def execute(self) -> [list, dict]:
        get_2pic = None
        self.cfg3d = cfg.configs['3d']
        Results = [{
            "box_info": [],
            "prealarm_pic": []
        }]
        Alarm = {"3dalarm":[]}
        # 删除list  加入 图片
        remove_listPic = []
        # remove_listPic = [self.cameraInfo.fileName1, self.cameraInfo.fileName1.replace(".jpeg", ".jpeg"),
        #                   self.cameraInfo.fileName1.replace(".jpeg", "_2.jpeg")]
        try:
            # 模型配置文件 内容提取
            in_modelcfg = cfg.logicModelDict[self.logicModelName]  # 对呀分析类型的 config
            bigtimes = len(in_modelcfg.keys()) - 1  # 模型放大次数
            bigcont = in_modelcfg['param']['auto']  # 放大内容
            height, width, channl = self.picture.shape  # 图片维度
            #  拉近框 放大
            boundingboxs = [
                BoundingBox(0, 0.8, bigcont[0] * width - 100, bigcont[0] * width + 100, bigcont[1] * height - 100,
                            bigcont[1] * height + 100, width, height, 'smoke')] if len(bigcont) == 2 else []
            # 没有分析到  并且 没有配置主动拉近

            if len(self.logicResult) == 0 and bigcont == []:
                return [], []
            boundingboxs = self.logicResult if len(boundingboxs) == 0 else boundingboxs
            threeD_pics = []
            logger.info(f"bigtime:{boundingboxs}")
            for objnum,boxs in enumerate(boundingboxs):
                boxInfo = boxs
                # 每条报警产生的数据
                picture_info = {}
                alarm_flag = False
                # 每条报警产生 的首条 内容
                boxs.classname = self.logicModelName
                threeD_bounding = [boxs]
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 开始3D放大逻辑({bigtimes}次) 首次放大框: {threeD_bounding}')
                threeD_pic = []
                p, t, z = -1, -1, -1
                # 每个框 放大次数
                infoX1 = boxs.x1
                infoY1 = boxs.y1
                infoW1 = boxs.width()
                infoH1 = boxs.height()
                getpic = self.picture
                for bigtime in range(1, bigtimes):
                    analyseMain = in_modelcfg[bigtime]['main']  # 主要分析标签
                    # 放大几个框
                    picture_info['deviceID'] = self.cameraInfo.deviceId
                    picture_info['preset'] = self.cameraInfo.presetId
                    picture_info['xTop'] = infoX1
                    picture_info['yTop'] = infoY1
                    picture_info['xWidth'] = infoW1
                    picture_info['yLength'] = infoH1
                    picture_info['picWidth'] = width
                    picture_info['picLength'] = height
                    picture_info['picDir'] = os.path.join(self.cfg3d['3d_sendpath'])  # self.camera_info['dir']")
                    # 首次放大的车辆需要比对
                    comparePicture = getpic[int(boxInfo.y1):int(boxInfo.y2), int(boxInfo.x1):int(boxInfo.x2)]
                    picture_info[
                        'picName'] = f"{os.path.basename(self.cameraInfo.fileName1).split('.')[0]}obj_{objnum}get{bigtime}"
                    logger.info(
                        f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime}次放大 放大标签:{analyseMain} HTTP 放大内容:{picture_info} ')
                    response_json = self.http_post_threeD(picture_info, self.cameraInfo.snap)
                    getnum_path = os.path.join(self.cfg3d["3d_recepath"], picture_info['picName'])
                    remove_listPic.append(getnum_path + '.json')
                    remove_listPic.append(getnum_path + '.jpeg')
                    remove_listPic.append(getnum_path + '_2.jpeg')
                    # 抓图是否调用成功
                    if response_json['code'] == 0:
                        time.sleep(3)
                        # 判断是否 成功抓取图片
                        if self.triplicate(getnum_path):
                            # 获取pic的信息
                            json_data = json.load(open(getnum_path + '.json', encoding='utf8'))
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 抓图成功 json{json_data}')
                            p, t, z = json_data['p'], json_data['t'], json_data['z']
                            # 对最后一次车牌识别 时传入的图片为扣取的车辆图片。
                            getpic = cv2.imread(getnum_path + '.jpeg')
                            get_2pic = cv2.imread(getnum_path + '_2.jpeg')
                            # 模型推理
                            labels_lists = cfg.logicModelDict[self.logicModelName][bigtime]['label']
                            result = analyseRun(labels_lists, [getpic, get_2pic], self.cameraInfo,box_info=boxInfo)
                            index = 0
                            # 当前拉近切出来的图片。
                            cutimgs = [getpic[int(boxInfo.y1):int(boxInfo.y2),int(boxInfo.x1):int(boxInfo.x2)] for boxInfo in result]
                            # 保障同一辆车拉近。返回匹配度最高的 index
                            if len(cutimgs)==0:
                                break
                            simear,index = compare_images(comparePicture,cutimgs,self.cameraInfo.baseNameSplit,bigtime,conf=0.4)
                            # 识别
                            logger.info(f"bigindex:{simear}, {index}")
                            # 如果匹配失败，我就直接识别车牌。
                            if simear is None or index is None:
                               
                                labels_lists = cfg.logicModelDict[self.logicModelName][bigtime]['label']
                                result = analyseRun(labels_lists, [getpic, get_2pic], self.cameraInfo, box_info=boxInfo)
                                boxInfo = result[0]
                                getpic2 = getpic.copy()
                                if width*0.2< boxInfo.x1 + boxInfo.width()< width*0.85:
                                    # for resInfo in result:
                                    boxInfo.threeDtimes = bigtime
                                    boxInfo.classname = self.logicModelName
                                    # cv2.rectangle(getpic2, (boxInfo.x1, boxInfo.y1), (
                                    #    boxInfo.x2, boxInfo.y2), 3, 1)
                                    threeD_bounding.append(boxInfo)
                                    threeD_pic.append(getpic2)
                                else:
                                    bigtime-=1
                                break
                            boxInfo = result[index]
                            infoX1 = boxInfo.x1
                            infoY1 = boxInfo.y1
                            infoW1 = boxInfo.width()
                            infoH1 = boxInfo.height()
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次分析结果{result} ')
                            noreslist = []
                            # 如果放大分析没有分析到结果
                            if len(result) == 0:
                                logger.info(
                                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 没有检测到 ')
                                break
                            # 循环所有结果，if 存在 主标签就放大，不存在就跳过
                            labels_dicts = [i.classname for i in result]
                            # 判断此次是否产生报警
                            alarm_flag = False
                            flagList = []
                            for i in analyseMain:
                                if i in labels_dicts:
                                    flagList.append(i)
                            if len(flagList) <= len(analyseMain) and len(flagList) > 0:
                                alarm_flag = True
                            else:
                                logger.info(
                                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 不在主标签内{analyseMain} {labels_dicts.keys()} ')
                                break
                            # 产生报警
                            getpic2 = getpic.copy()
                            # for resInfo in result:
                            boxInfo.threeDtimes = bigtime
                            boxInfo.classname = self.logicModelName
                            #cv2.rectangle(getpic2, (boxInfo.x1, boxInfo.y1), (
                            #    boxInfo.x2, boxInfo.y2), 3, 1)
                            threeD_bounding.append(boxInfo)
                            threeD_pic.append(getpic2)
                        else:
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 抓图失败')
                            break
                    else:
                        logger.info(
                            f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 HTTP 调用失败')
                # 删除报警，且bigtime 必须执行到最后一步。
                if alarm_flag and bigtimes -1 == bigtime:
                    self.cameraInfo.ptz = {'pans': p, 'zoom': z, 'tilt': t}
                    otherInfos = threeD_bounding[-1].parames_vector
                    otherInfos.update(self.cameraInfo.ptz)
                    threeD_bounding.append(BoundingBox(0, 0.0, 0, 1, 0, 1, width, height,self.logicModelName,threeDtimes=-1,parames_vector=otherInfos))
                    Alarm["3dalarm"].append(threeD_bounding.copy())
                    logger.info(f"3dalarmbig:{Alarm}")
                    threeD_pic.append(cv2.imread(f"Picture_pkl/{self.cameraInfo.deviceId}/{self.cameraInfo.presetId}/illegal-car/saveold.jpeg"))
                    threeD_pics.append(threeD_pic.copy())
                    logger.info(
                        f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} ->  3D_logic 报警产生: {Results}')
                self.http_threeD_orign(self.cameraInfo.deviceId, self.cameraInfo.presetId, self.cameraInfo.snap)
        except Exception as e:
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e}')
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e.__traceback__.tb_frame.f_globals["__file__"]}')
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e.__traceback__.tb_lineno}')

        finally:
            for path in remove_listPic:
                self.del_file(path)
            self.http_threeD_close(self.cameraInfo.deviceId, self.cameraInfo.presetId, self.cameraInfo.snap)
        return Alarm, threeD_pics

    def __del__(self):
        """
        后处理  类注销前操作的 内容  或者 抛出 无法捕捉的异常报错  执行的内容
        :return:
        """
        pass

