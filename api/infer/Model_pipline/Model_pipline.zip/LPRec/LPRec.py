# -*- coding: utf-8 -*-
#人脸
import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from aiutils.model import catcher
class Model(ModelClass):
    def execute(self):
        try:
            typeid = ["蓝牌","黄牌单层","白牌单层","绿牌新能源","黑牌港澳","香港单层","香港双层","澳门单层","澳门双层","黄牌双层","未知车牌"]
            height,width,channle = self.picture.shape
            lpr = catcher(self.picture)
            print(f"lprrr{lpr}") 
            if len(lpr)!=0:
                idcard,conf,index,box = catcher(self.picture)[0]
                return [BoundingBox(0, float(conf), box[0],box[2],box[1],box[3],width,height ,self.logicModelName,parames_vector={"idcard":idcard,"idtype":typeid[index]})],[]
            return  [BoundingBox(0, 0,0,1,0,1,width,height ,self.logicModelName,parames_vector={"idcard":"noidcard","idtype":"无车牌"})],[]
              
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [],[]


