# -*- coding: utf-8 -*-
# 人脸
import os
from time import sleep, localtime, strftime, time
import numpy as np
import cv2
import requests
from datetime import datetime, timedelta
import json
import uuid
from Utils.boundingbox import BoundingBox
from running import analyseRun
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.config import cfg
from Utils.utils import UpdateDeviceStatus
from Utils.Sql_utils import iou
import math


class Model(ModelClass):

    # 3d 调用 接口
    def http_post_threeD(self, picture_info, snap, bigtime,dirName):
        # req_list = [grequests.post("127.0.0.1:8500",json = {},timeout=60)]
        self.session = requests.session()
        response_dicts = {}
        response_dicts['code'] = -1

        try:

            for i in range(self.cfg3d['resend']):
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capurlIp']}:{22233 if dirName in [str(i) for i in range(30,36)] else 8000 + int(snap)}/{self.cfg3d['3d_capurl']}",
                    data=picture_info, timeout=40)
                response_dicts = response_dicts.json()
                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
        except Exception as e:
            print(e)
            response_dicts['code'] = -5
            # self.sqlLite.sql(f'''UPDATE betalog SET get_{bigtime}info ="ERROR1 抓图失败" WHERE filename="{self.cameraInfo.baseName}"''')
            print(e.__traceback__.tb_lineno)
            print(e.__traceback__.tb_frame.f_globals["__file__"])

        finally:
            self.session.close()
            return response_dicts

    def triplicate(self, savepath):
        flag = True
        for suffix in ['.jpeg', '_2.jpeg', '.json']:

            if os.path.isfile(savepath + suffix) == False:
                flag = False
        return flag

    def del_file(self, path):
        if os.path.isfile(path):
            os.remove(path)

    def euclidean_distance(self, a, b):
        x1, y1 = a
        x2, y2 = b
        distance = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
        return distance

    def local_date(self):  # 年月日
        return strftime('%Y%m%d', localtime(time()))

    def http_threeD_orign(self, deviceID, preset, snap,dirName):
        close_data = {
            'deviceID': deviceID,
            'preset': str(preset),
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'close'
        }
        self.session = requests.session()
        response_dicts = {}
        for i in range(1):
            try:
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capcloseIp']}:{22233 if dirName in [str(i) for i in range(30,36)] else 8000 + int(snap)}/api/goto/preset",
                    data=close_data, timeout=30)
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |DIR-{self.cameraInfo.dirName}  {os.path.basename(self.cameraInfo.fileName1)} -> goto_preset{response_dicts.json()}')
                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
            except Exception as e:
                print(e)
                print(e.__traceback__.tb_lineno)
                print(e.__traceback__.tb_frame.f_globals["__file__"])

            finally:
                self.session.close()
                return response_dicts

    def siou(self, box1, box2):
        intersection_width = min(box1.x2, box2.x2) - max(box1.x1, box2.x1)
        intersection_height = min(box1.y2, box2.y2) - max(box1.y1, box2.y1)
        if intersection_width <= 0 or intersection_height <= 0:
            return 0.0
        intersection_area = intersection_width * intersection_height
        box1_area = box1.width() * box1.height()
        box2_area = box2.width() * box2.height()

        iou = intersection_area / min(box1_area, box2_area)  # float(box1_area + box2_area - intersection_area)
        return iou

    def http_threeD_close(self, deviceID, preset, snap,dirName):
        close_data = {
            'deviceID': deviceID,
            'preset': str(preset),
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'close'
        }
        self.session = requests.session()
        response_dicts = {}
        for i in range(1):
            try:
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 准备释放设备 http://{self.cfg3d["3d_capcloseIp"]}:{8000 + int(snap)}/{self.cfg3d["3d_capcloseUrl"]}')
                response_dicts = self.session.post(
                    f"http://{self.cfg3d['3d_capcloseIp']}:{22233 if dirName in [str(i) for i in range(30,36)] else 8000 + int(snap)}/{self.cfg3d['3d_capcloseUrl']}",
                    data=close_data, timeout=30)
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 释放3d设备成功')

                break
            # postmain = grequests.map(req_list,exception_handler=self.exception_handler)
            except Exception as e:
                print(e)
                print(e.__traceback__.tb_lineno)
                print(e.__traceback__.tb_frame.f_globals["__file__"])

            finally:
                self.session.close()
                return response_dicts

    def execute(self) -> [list, dict]:
        localdate = self.local_date()
        # 设备状态更新
        UpdateDeviceStatus(self.cameraInfo.deviceId, '1')
        if os.path.isdir(f"/volume/3dalarms2/fire/{localdate}") == False:
            #    os.makedirs(f"/volume/otheralarms/fire/{localdate}/smoke")
            #    os.makedirs(f"/volume/otheralarms/fire/{localdate}/nosmoke")
            os.makedirs(f"/volume/3dalarms2/fire/{localdate}/get")
            os.makedirs(f"/volume/3dalarms2/fire/{localdate}/smoke")
            os.makedirs(f"/volume/3dalarms2/fire/{localdate}/get/txt")
            os.makedirs(f"/volume/3dalarms2/fire/{localdate}/smoke/txt")    
        get_2pic = None
        self.cfg3d = cfg.configs['3d']
        Results = [{
            "box_info": [],
            "prealarm_pic": []
        }]
        Alarm = {"3dalarm": []}
        # 删除list  加入 图片
        remove_listPic = []
        # remove_listPic = [self.cameraInfo.fileName1, self.cameraInfo.fileName1.replace(".jpeg", ".jpeg"),
        #                   self.cameraInfo.fileName1.replace(".jpeg", "_2.jpeg")]
        try:
            # 模型配置文件 内容提取
            in_modelcfg = cfg.logicModelDict[self.logicModelName]  # 对呀分析类型的 config
            bigtimes = len(in_modelcfg.keys()) - 1  # 模型放大次数
            bigcont = in_modelcfg['param']['auto']  # 放大内容
            height, width, channl = self.picture.shape  # 图片维度
            #  拉近框 放大
            boundingboxs = [
                BoundingBox(0, 0.8, bigcont[0] * width - 100, bigcont[0] * width + 100, bigcont[1] * height - 100,
                            bigcont[1] * height + 100, width, height, 'smoke')] if len(bigcont) == 2 else []
            if len(self.logicResult) == 0 and bigcont == []:
                return [], []
            boundingboxs = self.logicResult if len(boundingboxs) == 0 else boundingboxs
            threeD_pics = []
            logger.info(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 开始3D放大逻辑  1共有放大框{len(boundingboxs)}个: {boundingboxs}')
            '''
            for one, i in enumerate(boundingboxs):
                for two, b in enumerate(boundingboxs):
                    if one != two:
                        ious = self.siou(i, b)
                        if ious > 0.05:
                            boundingboxs.remove(b)
                            logger.info(f"{os.path.basename(self.cameraInfo.fileName1)} ->nuonuonuo{ious} {b}")
            '''
            while 1:
                removed = False
                for one,i in enumerate(boundingboxs):
                    for two,b in enumerate(boundingboxs):
                        if one != two:
                            ious = self.siou(i, b)
                            if ious > 0.05:
                                boundingboxs.remove(b)
                                removed = True
                                break
                if not removed:
                    break
            logger.info(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 开始3D放大逻辑  2共有放大框{len(boundingboxs)}个: {boundingboxs}')
            for objnum, boxs in enumerate(boundingboxs):
                boxInfo = boxs
                # 每条报警产生的数据
                picture_info = {}
                alarm_flag = False
                # 每条报警产生 的首条 内容
                boxs.classname = self.logicModelName
                threeD_bounding = [boxs]
                logger.info(
                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 开始3D放大逻辑({bigtimes}次) 首次放大框: {threeD_bounding}')
                threeD_pic = []
                p, t, z = -1, -1, -1
                # 每个框 放大次数
                infoX1 = boxs.x1
                infoY1 = boxs.y1
                infoW1 = boxs.width()
                infoH1 = boxs.height()
                getpic = self.picture
                for bigtime in range(1, bigtimes):
                    analyseMain = in_modelcfg[bigtime]['main']  # 主要分析标签
                    # 放大几个框
                    picture_info['deviceID'] = self.cameraInfo.deviceId
                    picture_info['preset'] = self.cameraInfo.presetId
                    picture_info['xTop'] = infoX1
                    picture_info['yTop'] = infoY1
                    picture_info['xWidth'] = infoW1
                    picture_info['yLength'] = infoH1
                    picture_info['picWidth'] = width
                    picture_info['picLength'] = height
                    picture_info['picDir'] = os.path.join(self.cfg3d['3d_sendpath'])  # self.camera_info['dir']")
                    picture_info[
                        'picName'] = f"{os.path.basename(self.cameraInfo.fileName1).split('.')[0]}obj_{objnum}get{bigtime}"
                    logger.info(
                        f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime}次放大 放大标签:{analyseMain} HTTP 放大内容:{picture_info} ')
                    # self.sqlLite.sql(f'''UPDATE betalog SET get_{bigtime} ="{picture_info['picName']}.jpeg" WHERE filename="{self.cameraInfo.baseName}"''')
                    response_json = self.http_post_threeD(picture_info, self.cameraInfo.snap, bigtime,self.cameraInfo.dirName)
                    getnum_path = os.path.join(self.cfg3d["3d_recepath"], picture_info['picName'])
                    remove_listPic.append(getnum_path + '.json')
                    remove_listPic.append(getnum_path + '.jpeg')
                    remove_listPic.append(getnum_path + '_2.jpeg')
                    # 抓图是否调用成功
                    if response_json['code'] == 0:
                        sleep(3)
                        # 判断是否 成功抓取图片
                        if self.triplicate(getnum_path):
                            # self.sqlLite.sql(f'''UPDATE betalog SET get_{bigtime}info ="{picture_info}" WHERE filename="{self.cameraInfo.baseName}"''')
                            # 获取pic的信息
                            json_data = json.load(open(getnum_path + '.json', encoding='utf8'))
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 抓图成功 json{json_data}')
                            # p, t, z = json_data['p'], json_data['t'], json_data['z']
                            try:
                                # 对最后一次车牌识别 时传入的图片为扣取的车辆图片。
                                getpic = cv2.imread(getnum_path + '.jpeg')  # 919add
                                h1, w1, c1 = getpic.shape
                                get_2pic = cv2.imread(getnum_path + '_2.jpeg')
                            except Exception as e:
                                print(f"sss{e}")
                                break
                            # 模型推理
                            labels_lists = cfg.logicModelDict[self.logicModelName][bigtime]['label']
                            self.cameraInfo.reserveParam = os.path.basename(getnum_path + '.jpeg')
                            result = analyseRun(labels_lists, [get_2pic,getpic], self.cameraInfo, box_info=boxInfo)
                            if len(result) <= 0:
                                logger.info(
                                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 抓图成功 没有分析到目标')
                                break
                            # 919 add
                            current_time = datetime.now().time()  # 获取当前系统时间
                            start_time = datetime.strptime('17:30', '%H:%M').time()
                            end_time = (datetime.strptime('08:30', '%H:%M') + timedelta(days=1)).time()  # 第二天早上8:30
                            center = (w1 // 2, h1 // 2)
                            distense = []
                            for bounding in result:
                                distances = self.euclidean_distance(center, bounding.center_boxs())
                                distense.append(distances)
                            minindex = np.argmin(distense)
                            boxInfo = result[minindex]
                            infoX1 = boxInfo.x1
                            infoY1 = boxInfo.y1
                            infoW1 = boxInfo.width()
                            infoH1 = boxInfo.height()
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次分析结果{result} ')
                            noreslist = []
                            # 如果放大分析没有分析到结果
                            if len(result) == 0:
                                logger.info(
                                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 没有检测到 ')
                                break
                            # 循环所有结果，if 存在 主标签就放大，不存在就跳过
                            labels_dicts = [i.classname for i in result]
                            # 判断此次是否产生报警
                            alarm_flag = False
                            flagList = []
                            for i in analyseMain:
                                if i in labels_dicts:
                                    flagList.append(i)
                            if len(flagList) <= len(analyseMain) and len(flagList) > 0:
                                alarm_flag = True
                            else:
                                logger.info(
                                    f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 不在主标签内{analyseMain} {labels_dicts.keys()} ')
                                break
                            # 产生报警
                            getpic2 = getpic.copy()
                            getpic3 = get_2pic.copy()
                            boxInfo.threeDtimes = bigtime
                            boxInfo.classname = self.logicModelName
                            p, t, z = json_data['p'], json_data['t'], json_data['z']
                            for boxi in result:
                                boxi.threeDtimes = bigtime
                                boxi.classname = self.logicModelName
                                boxi.parames_vector = {'pans': p, 'zoom': z, 'tilt': t}
                                threeD_bounding.append(boxi)
                            threeD_pic.append([getpic2,getpic3])
                        else:
                            # self.sqlLite.sql(f'''UPDATE betalog SET get_{bigtime}info ="ERROR3 抓图接口成功没有找到放大图片" WHERE filename="{self.cameraInfo.baseName}"''')
                            logger.info(
                                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 抓图失败{alarm_flag}')
                            break
                    else:
                        # if response_json['code'] == -5:
                        # self.sqlLite.sql(f'''UPDATE betalog SET get_{bigtime}info ="ERROR2 抓图失败" WHERE filename="{self.cameraInfo.baseName}"''')
                        logger.info(
                            f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic 第{bigtime + 1}次放大 HTTP 调用失败{alarm_flag}')
                        break
                # 删除报警，且bigtime 必须执行到最后一步。
                if alarm_flag:
                    self.cameraInfo.ptz = {'pans': p, 'zoom': z, 'tilt': t}
                    # otherInfos = threeD_bounding[-1].parames_vector
                    # otherInfos.update(self.cameraInfo.ptz)
                    threeD_bounding[-1].parames_vector = self.cameraInfo.ptz

                    threeD_bounding.append(
                        BoundingBox(0, 0.0, 0, 1, 0, 1, width, height, self.logicModelName, threeDtimes=-1,
                                    parames_vector=threeD_bounding[-1].parames_vector))
                    Alarm["3dalarm"].append(threeD_bounding.copy())
                    threeD_pics.append(threeD_pic.copy())
                    logger.info(
                        f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] | DIR-{self.cameraInfo.dirName} {os.path.basename(self.cameraInfo.fileName1)} ->  3D_logic 报警产生: {Results}')
                self.http_threeD_orign(self.cameraInfo.deviceId, self.cameraInfo.presetId, self.cameraInfo.snap,self.cameraInfo.dirName)
        except Exception as e:
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e}')
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e.__traceback__.tb_frame.f_globals["__file__"]}')
            logger.error(
                f'DeviceID [{self.cameraInfo.deviceId}] | Preset [{self.cameraInfo.presetId}] |  {os.path.basename(self.cameraInfo.fileName1)} -> 3D_logic {e.__traceback__.tb_lineno}')

        finally:
            for path in remove_listPic:
                self.del_file(path)
            self.http_threeD_close(self.cameraInfo.deviceId, self.cameraInfo.presetId, self.cameraInfo.snap,self.cameraInfo.dirName)
        return Alarm, threeD_pics

    def __del__(self):
        """
        后处理  类注销前操作的 内容  或者 抛出 无法捕捉的异常报错  执行的内容
        :return:
        """
        pass

