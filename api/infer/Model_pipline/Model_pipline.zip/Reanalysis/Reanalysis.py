# -*- coding: utf-8 -*-
# 人脸
import copy
import uuid
import cv2
import numpy as np

from Utils.analyse_utils import *
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from running import analyseRun

class Node():
    # 初始化一个节点
    def __init__(self, val=None, level=0, lastname=""):
        self.val = val  # 节点值
        self.level = level
        self.l_child = []  # 子节点列表
        self.last_nodename = lastname

    # 添加子节点
    def add_child(self, node):
        self.l_child.append(node)


class Model(ModelClass):
    def tree(self, boundingboxs, iters, root, last_name="0", j=0, x_offset=0, y_offset=0):
        j += 1
        # 每一次调用都是一个 新的 分析
        if j < iters:
            labels = cfg.logicModelDict[self.logicModelName][j]['label']
            models = LabelToModel(labels, cfg.unlogicModelDict)
            # 第一次是 检测到自行车的boxs  给首次目标创建 父节点
            for i, info in enumerate(boundingboxs):
                uuidcreate = str(uuid.uuid4())
                child = Node(info, j, last_name)
                # absolute_x1 = info.x1 + x_offset
                # absolute_x2 = absolute_x1 + info.width()
                # absolute_y1 = info.y1 + y_offset
                # absolute_y2 = absolute_y1 + info.height()
                cut_img = self.picture[info.y1:info.y2, info.x1:info.x2]
                x_offset += info.x1
                y_offset += info.y1
                boundingboxs = []
                boundingboxs += analyseRun(labels,[cut_img,cut_img],self.cameraInfo,box_info=info)
                # 更新偏移量
                for bounding in boundingboxs:
                    # 更新 BoundingBox 对象的坐标
                    bounding.x1 = bounding.x1 + x_offset
                    bounding.x2 = bounding.x2 + x_offset
                    bounding.y1 = bounding.y1 + y_offset
                    bounding.y2 = bounding.y2 + y_offset

                # 添加父节点
                root[uuidcreate] = child
                # 构建 递归树
                self.tree(boundingboxs, iters, root, uuidcreate, j, x_offset, y_offset)
            if j > iters:
                return root
        else:
            for i, info in enumerate(boundingboxs):
                uuidcreate = str(uuid.uuid4())
                child = Node(info, j, last_name)
                root[uuidcreate] = child

            return root
        return root

    def result_export(self, root, result_label: [], iters):
        reslist = []

        h,w = self.picture.shape[:2]
        resnode = []
        for k, llastnode in root.items():

            if llastnode.val.classname in cfg.logicModelDict[self.logicModelName][iters - 1]['label']:
                while True:
                    # 上一节点的
                    resnode.append(llastnode)
                    llastnode = root[llastnode.last_nodename]
                    if llastnode.val.classname == cfg.logicModelDict[self.logicModelName]['param']['result_label']:
                        # resnode.append(llastnode)
                        bounding = BoundingBox(0,1.0,llastnode.val.x1,llastnode.val.x2,llastnode.val.y1,llastnode.val.y2,llastnode.val.image_width,llastnode.val.image_height,self.logicModelName,parames_vector=llastnode.val.parames_vector)
                        bounding.mask = llastnode.val.mask
                        bounding.orig_classname = llastnode.val.classname
                        reslist.append(bounding)
                        break
            # if llastnode.val.classname == cfg.logicModelDict[self.logicModelName]['param']['result_label']:
            #     reslist.append(
            #         BoundingBox(0, 1.0, llastnode.val.x1, llastnode.val.x2, llastnode.val.y1, llastnode.val.y2,
            #                     w, h, self.logicModelName,
            #                     parames_vector=llastnode.val.parames_vector,mask=llastnode.val.mask))
        return reslist

    # 节点 方式
    def execute(self) -> [list, dict]:
        reslist = []
        try:
            iters = len(cfg.logicModelDict[self.logicModelName]) - 1
            result_label = cfg.logicModelDict[self.logicModelName]['param']['result_label']
            result_label = [result_label]
            root = {}
            self.tree(self.logicResult, iters, root)
            reslist = self.result_export(root, result_label, iters)
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)
        return reslist, []
