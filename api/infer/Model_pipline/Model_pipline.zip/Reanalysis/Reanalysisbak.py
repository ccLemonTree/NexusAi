# -*- coding: utf-8 -*-
# 人脸
import copy
import uuid
import cv2
from Utils.analyse_utils import *
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from running import analyseRun

class Node():
    # 初始化一个节点
    def __init__(self, val=None, level=0, lastname=""):
        self.val = val  # 节点值
        self.level = level
        self.l_child = []  # 子节点列表
        self.last_nodename = lastname

    # 添加子节点
    def add_child(self, node):
        self.l_child.append(node)


class Model(ModelClass):
    def tree(self, boundingboxs, iters, picture, root, last_name="0", j=0, width=0, height=0):
        j += 1
        # 每一次调用都是一个 新的 分析
        if j < iters:
            labels = cfg.logicModelDict[self.logicModelName][j]['label']
            models = LabelToModel(labels, cfg.unlogicModelDict)
            # 第一次是 检测到自行车的boxs  给首次目标创建 父节点
            for i, info in enumerate(boundingboxs):
                uuidcreate = str(uuid.uuid4())
                child = Node(info, j, last_name)
                cut_img = picture[info.y1:info.y2, info.x1:info.x2]
                boundingboxs = []
                boundingboxs += analyseRun(labels,[cut_img,cut_img],self.cameraInfo,box_info=info)
                # for aly, value in models.items():
                #     boundingboxs += analyseRun
                #     boundingboxs += self.tritonServer.run(aly, cut_img, self.cameraInfo, label_to_detect=value,
                #                                           box_info=info)

                # 添加父节点
                root[uuidcreate] = child
                # 构建 递归树
                self.tree(boundingboxs, iters, cut_img, root, uuidcreate, j, width, height)
            if j > iters:
                return root
        else:
            for i, info in enumerate(boundingboxs):
                uuidcreate = str(uuid.uuid4())
                child = Node(info, j, last_name)
                root[uuidcreate] = child

            return root
        return root

    def result_export(self, root, result_label: [], iters):
        reslist = []
        resnode = []
        for k, llastnode in root.items():
            if llastnode.val.classname in cfg.logicModelDict[self.logicModelName][iters - 1]['label']:
                while True:
                    # 上一节点的
                    resnode.append(llastnode)
                    llastnode = root[llastnode.last_nodename]
                    if llastnode.last_nodename == '0':
                        # resnode.append(llastnode)

                        bounding = BoundingBox(0,1.0,llastnode.val.x1,llastnode.val.x2,llastnode.val.y1,llastnode.val.y2,llastnode.val.image_width,llastnode.val.image_height,self.logicModelName,parames_vector=llastnode.val.parames_vector)
                        bounding.mask = llastnode.val.mask
                        reslist.append(bounding)
                        break
        # for node in resnode:
        #     if node.val.classname in result_label:
        #         x1 = node.val.x1
        #         x2 = node.val.x2
        #         y1 = node.val.y1
        #         y2 = node.val.y2
        #         node_copy = copy.copy(node)
        #         while True:
        #             if node.last_nodename == '0':
        #                 reslist.append(BoundingBox(0, 1.0, x1, x2, y1, y2, node_copy.val.image_width, node_copy.val.image_height,
        #                                            self.logicModelName,parames_vector=node_copy.val.parames_vector))
        #                 break
        #                 # 上一节点的
        #             node = root[node.last_nodename]
        #             # x2 += x1
        #             # x1 += node.val.x1
        #             # y1 += node.val.y1
        #             # y2 += y1
        return reslist

    # 节点 方式
    def execute(self) -> [list, dict]:
        reslist = []
        try:
            iters = len(cfg.logicModelDict[self.logicModelName]) - 1
            result_label = cfg.logicModelDict[self.logicModelName]['param']['result_label']
            result_label = [result_label]
            root = {}
            self.tree(self.logicResult, iters, self.picture, root)
            reslist = self.result_export(root, result_label, iters)
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)
        return reslist, []
