# -*- coding: utf-8 -*-
#人脸
import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger

class Model(ModelClass):
    def execute(self):
        try:
            height,width,channle = self.picture.shape
            k = 0
            appends = []
            for info in self.logicResult:
                if info.classname in cfg.logicModelDict[self.logicModelName][1]['label']:
                    appends.append(info)
                    k+=1
            if k >=cfg.logicModelDict[self.logicModelName]["param"]["num"]:
                # points = []
                # for j in appends:
                #     points.append([[j.x1,j.y1]])
                #     points.append([[j.x2, j.y1]])
                #     points.append([[j.x1, j.y2]])
                #     points.append([[j.x2, j.y2]])
                # x,y,w,h = cv2.boundingRect(np.array(points))
                return appends,[]
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [],[]


