import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from running import analyseRun

class Model(ModelClass):

    def execute(self):
        try:
            boundingboxs = []
            labels = cfg.logicModelDict[self.logicModelName][1]['label']
            for info in self.logicResult:
                cut_img = self.picture[info.y1:info.y2, info.x1:info.x2]
                boundingboxs += analyseRun(labels, [cut_img, cut_img], self.cameraInfo, box_info=info)
            for infos in boundingboxs:
                infos.classname = self.logicModelName
                logger.error(infos)
            return boundingboxs,[]
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [],[]