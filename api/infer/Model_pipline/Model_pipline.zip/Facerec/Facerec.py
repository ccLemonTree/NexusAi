# -*- coding: utf-8 -*-
#人脸
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.result_utils import LabelToModel
from Utils.utils import Cos_Similarity
import struct
from Utils.redis_Utils import redisServer
class Model(ModelClass):
    def execute(self):
        redis_client = redisServer.get_connection()
        faceType = 0 if "black" in self.logicModelName else 1
        try:
            # 人脸
            boundingboxs = []
            labels = cfg.logicModelDict[self.logicModelName][1]['label']
            maxflag = cfg.logicModelDict[self.logicModelName]['param']['maxface']
            models = LabelToModel(labels, cfg.unlogicModelDict)
            # 第一次是 检测到人脸的boxs
            for i, info in enumerate(self.logicResult):
                cut_img = self.picture[info.y1:info.y2, info.x1:info.x2]
                for aly, value in models.items():
                    # 检测 face vector
                    boundingboxs += self.tritonServer.run(aly, cut_img, self.cameraInfo, label_to_detect=value,
                                                          box_info=info)
            conf = []
            if len(boundingboxs)==0:
                return [], []
            maxId = np.argmax([i.width() for i in boundingboxs])
            maxVector = boundingboxs[maxId]
            features1 = maxVector.parames_vector['vector']
            userId = redis_client.smembers('face:white:list' if faceType else 'face:black:list')
            userId = list(userId)
            allVector = []
            for id in userId:
                id = id.decode('utf-8')
                dataVector = redis_client.smembers('face:vector:'+id)
                for byte_string_list in dataVector:
                    features2 = []
                    for i in range(0, len(byte_string_list), 4):
                        value = struct.unpack('f', byte_string_list[i:i + 4])
                        features2.append(value[0])
                # print(my_vector)
                # print(np.array(my_vector).shape)
                    conf.append(Cos_Similarity(features1,features2))
            if len(conf)==0:
                return [],[]
            faceMaxConfIndex = np.argmax(conf)
            print(conf[faceMaxConfIndex])
            if conf[faceMaxConfIndex] > cfg.logicModelDict[self.logicModelName]['param']['conf']:
                faceInfo = redis_client.hgetall('face:info:'+userId[faceMaxConfIndex].decode('utf-8'))
                decoded_dict = {key.decode('utf-8'): value.decode('utf-8') for key, value in faceInfo.items()}
                #result = self.logicResult[faceMaxConfIndex]
                #result.classname = self.logicModelName
                #result.parames_vector = {'faceInfo':decoded_dict}
                return [BoundingBox(0,conf[faceMaxConfIndex],0,0,1,1,1,1,self.logicModelName,{'faceInfo':decoded_dict})],[]
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)
        finally:
            redis_client.close()

        return [],[]


