# -*- coding: utf-8 -*-
# @Time    : 2024/4/12 9:43
# @Author  : 陈澔麟
# @File    : dogShen.py
# -*- coding: utf-8 -*-
# 人脸
import os
from time import strftime,localtime,time
import cv2
import numpy as np
from Utils.config import cfg
from Utils.result_utils import LabelToModel
from Utils.class_info import ModelClass
from Beta_Logging.log_utils import logger

class Model(ModelClass):
    def execute(self) -> [list, dict]:
        boundingboxs = []
        logicResult_copy = []
        box_infos = []
        labels = cfg.logicModelDict[self.logicModelName][1]['label']
        models = LabelToModel(labels, cfg.unlogicModelDict)
        # detect dog first one
        # cut sipxel num
        six = 100
        height, width, channle = self.picture.shape

        for info in self.logicResult:

            cutx1 = np.clip(int(info.x1-six),0,width)
            cuty1 = np.clip(int(info.y1-six),0,height)
            cutx2 = np.clip(int(info.x2+six),0,width)
            cuty2 = np.clip(int(info.y2+six),0,height)
            cut_img = self.picture[cuty1:cuty2,cutx1:cutx2]
            flag = True
            boundingboxs = []
            for aly, value in models.items():
                boundingboxs += self.tritonServer.run(aly, cut_img, self.cameraInfo, label_to_detect=value,
                                                      box_info=info)
                for bd in boundingboxs:
                    if bd.classname in labels:
                        flag = False
            if flag:
                info.classname = self.logicModelName
                box_infos.append(info)

        if len(box_infos) > 0:
            try:
                pathdpc = f"/volume/ai/alarm_save/dog/ql/{strftime('%Y%m%d', localtime(time()))}"
                os.makedirs(os.path.join(pathdpc, "images"), exist_ok=True)
                os.makedirs(os.path.join(pathdpc, "labels"), exist_ok=True)
                cv2.imwrite(os.path.join(os.path.join(pathdpc, "images"), self.cameraInfo.baseName), self.picture)
                with open(os.path.join(pathdpc, "labels", os.path.splitext(self.cameraInfo.baseName)[0] + '.txt'), "w") as f:
                    for writebox in box_infos:
                        cres = writebox.yolo_txt()
                        for i in cfg.unlogicModelDict.keys():
                            if writebox.orig_classname in cfg.unlogicModelDict[i]:
                                indexss = cfg.unlogicModelDict[i].index(writebox.orig_classname)
                        f.write(f"{indexss} {cres[0]} {cres[1]} {cres[2]} {cres[3]}\n")
            except Exception as e:
                logger.error(f"logic Lgdog {e}")
                logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
                logger.error(e.__traceback__.tb_lineno)
            finally:
                return box_infos,[]

        elif len(boundingboxs)>0:
            try:
                pathdpc = f"/volume/ai/alarm_save/dog/mq/{strftime('%Y%m%d', localtime(time()))}"
                os.makedirs(os.path.join(pathdpc, "images"), exist_ok=True)
                os.makedirs(os.path.join(pathdpc, "labels"), exist_ok=True)
                cv2.imwrite(os.path.join(os.path.join(pathdpc, "images"), self.cameraInfo.baseName), self.picture)
                with open(os.path.join(pathdpc, "labels", os.path.splitext(self.cameraInfo.baseName)[0] + '.txt'), "w") as f:
                    for writebox in box_infos:
                        cres = writebox.yolo_txt()
                        for i in cfg.unlogicModelDict.keys():
                            if writebox.orig_classname in cfg.unlogicModelDict[i]:
                                indexss = cfg.unlogicModelDict[i].index(writebox.orig_classname)
                        f.write(f"{indexss} {cres[0]} {cres[1]} {cres[2]} {cres[3]}\n")
            except Exception as e:
                logger.error(f"logic Lgdog {e}")
                logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
                logger.error(e.__traceback__.tb_lineno)
            finally:
                return [],[]
        return box_infos,[]

    def __del__(self):
        """
        后处理  类注销前操作的 内容  或者 抛出 无法捕捉的异常报错  执行的内容
        :return:
        """
        print('Cleaning up...')
