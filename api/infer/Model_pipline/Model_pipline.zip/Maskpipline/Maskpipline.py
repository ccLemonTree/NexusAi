# -*- coding: utf-8 -*-
# @Time    : 2024/1/18 14:55
# @Author  : 陈澔麟
# @File    : Maskpipline.py
# -*- coding: utf-8 -*-
# @Time    : 2024/1/12 15:48
# @Author  : 陈澔麟
# @File    : Proportion.py
# -*- coding: utf-8 -*-
import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
import copy
import uuid
import cv2
from Utils.analyse_utils import *
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from running import analyseRun

class Model(ModelClass):
    def execute(self):
        try:
            return_list = []
            for result in self.logicResult:
                cut_picture = self.picture[result.y1:result.y2, result.x1:result.x2]
                img2_fg = cv2.bitwise_and(cut_picture,cut_picture, mask=result.mask)
                labels = cfg.logicModelDict[self.logicModelName][1]['label']
                boundingboxs = analyseRun(labels,[img2_fg,img2_fg],self.cameraInfo,box_info=result)
                for boundingbox in boundingboxs:
                    result.confidence = boundingbox.confidence
                    result.classname = self.logicModelName
                    return_list.append(result)
            return return_list, []

        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [], []
