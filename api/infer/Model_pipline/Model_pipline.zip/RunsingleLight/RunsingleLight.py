# -*- coding: utf-8 -*-
#人脸
import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.result_utils import LabelToModel
class Model(ModelClass):
    def execute(self):
        try:
            width,height,channle = self.picture.shape
            k = 0
            redflag = False
            for info in self.logicResult:
                if info.classname in cfg.logicModelDict[self.logicModelName][0]['label']:
                    redflag = True
            if redflag:
                analyseLabel = cfg.logicModelDict[self.logicModelName][1]['label']
                appends = []
                for info in self.logicResult:
                    if info.classname in analyseLabel:
                        print(info)
                        appends.append(info)

                    return appends,[]
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [],[]


