# -*- coding: utf-8 -*-
"""
@author chenhaolin
@date 2023年04月18日 13:30:19
@packageName Triton
@className Reid.py
@version 1.0.0
@describe TODO
"""
# -*- coding: utf-8 -*-
# 人脸
import copy
import uuid
import cv2
from Utils.analyse_utils import *
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
import os,pickle

class Model(ModelClass):
    def get_relative_position(self,x1, y1, w1, h1, x2, y2, w2, h2):
        # 计算两个目标的中心点坐标
        center1_x, center1_y = x1 + w1 / 2, y1 + h1 / 2
        center2_x, center2_y = x2 + w2 / 2, y2 + h2 / 2

        # 判断目标的前后方位
        if center1_y < center2_y:
            front_back = 'front'
        elif center1_y > center2_y:
            front_back = 'back'
        else:
            front_back = ''
        # 判断目标的左右方位
        if center1_x < center2_x:
            left_right = 'left'
        elif center1_x > center2_x:
            left_right = 'right'
        else:
            left_right = ''

        # 判断目标的角落方位
        if front_back and left_right:
            if front_back == 'front' and left_right == 'left':
                corner = 'front-left'
            elif front_back == 'front' and left_right == 'right':
                corner = 'front-right'
            elif front_back == 'back' and left_right == 'left':
                corner = 'back-left'
            elif front_back == 'back' and left_right == 'right':
                corner = 'back-right'
            else:
                corner = ''
        else:
            corner = ''

        # 返回目标位置字符串
        if corner:
            return corner
        elif front_back:
            return front_back
        elif left_right:
            return left_right
        else:
            return 'same'

    def removeList(self,filename):
        for i in os.listdir(filename):
            file = os.path.join(filename,i)
            if os.path.isfile(file):
                os.remove(file)

    def Cos_Similarity(self,features1, features2):
        a_norm = np.linalg.norm(np.array(features1))
        b_norm = np.linalg.norm(np.array(features2))
        cos = np.dot(features1, features2) / (a_norm * b_norm)
        return cos

    # 节点 方式
    def execute(self) -> [list, dict]:
        try:
            filename = os.path.join(cfg.root_path,f"Picture_pkl/{self.cameraInfo.deviceId}/{self.cameraInfo.presetId}/{self.logicModelName}")
            # 当前 的特征点集合。
            boundingsboxs = []
            for info in self.logicResult:
                cut_img = self.picture[info.y1:info.y2, info.x1:info.x2]
                labels = cfg.logicModelDict[self.logicModelName][1]['label']
                models = LabelToModel(labels, cfg.unlogicModelDict)
                for key, value in models.items():
                    boundingsboxs += self.tritonServer.run(key, cut_img, self.cameraInfo, label_to_detect=value,
                                                           box_info=info)
            # 判断是否为空
            if os.path.exists(filename)==False:
                os.makedirs(filename)
            if len(os.listdir(filename))==0:

                for info2 in boundingsboxs:
                    info2 = info2()
                    with open(f"{filename}/{info2['ltx']}_{info2['lty']}_{info2['width']}_{info2['height']}", "wb") as f:
                        pickle.dump(info2["otherInfo"]['vector'], f)

            else:
                lastDictsInfo ={}
                for objname in os.listdir(filename):
                    with open(f"{filename}/{objname}", "rb") as f:
                        lastDictsInfo[objname] = pickle.load(f)
                for points,lvalue in lastDictsInfo.items():
                    allmaxs = []
                    for nowvalue in boundingsboxs:
                        nowvalue = nowvalue()
                        nvector = nowvalue['otherInfo']['vector']
                        sim = self.Cos_Similarity(lvalue,nvector)
                        allmaxs.append(sim)
                    # 取最优匹配 进行方向辨别
                    maxindex = np.argmax(allmaxs)
                    if allmaxs[maxindex]>0.9:
                        nowmaxsinfo = boundingsboxs[maxindex]
                        x1,x2,w1,h1 = [int(i) for i in points.split('_')]
                        a = self.get_relative_position(x1,x2,w1,h1,nowmaxsinfo.x1,nowmaxsinfo.y1,nowmaxsinfo.width(),nowmaxsinfo.height())
                        # imgg = cv2.rectangle(self.picture,(nowmaxsinfo.x1,nowmaxsinfo.y1),(nowmaxsinfo.x2,nowmaxsinfo.y2),(255,255,0),3,3)
                        # cv2.imshow("!",cv2.resize(imgg,(1920,1080)))
                        # cv2.waitKey(0)
                        # print(
                        #     "1111",a)
        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)
        # reslist = []
        # try:
        #     iters = len(cfg.logicModelDict[self.logicModelName]) - 1
        #     result_label = cfg.logicModelDict[self.logicModelName]['param']['result_label']
        #     result_label = [result_label]
        #     root = {}
        #     self.tree(self.logicResult, iters, self.picture, root)
        #     reslist = self.result_export(root, result_label, iters)
        # except Exception as e:
        #     logger.error(f"{self.logicModelName} {e}")
        #     logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
        #     logger.error(e.__traceback__.tb_lineno)
        return [], []
import datetime
