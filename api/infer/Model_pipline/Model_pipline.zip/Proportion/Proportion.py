# -*- coding: utf-8 -*-
# @Time    : 2024/1/12 15:48
# @Author  : 陈澔麟
# @File    : Proportion.py
# -*- coding: utf-8 -*-
import os.path

import cv2
import numpy as np

from Utils.class_info import ModelClass
from Utils.boundingbox import BoundingBox
from Utils.config import cfg
from Beta_Logging.log_utils import logger
from aiutils.model import catcher


class Model(ModelClass):
    def execute(self):
        try:
            return_list = []
            for result in self.logicResult:
                img2_fg = cv2.bitwise_and(self.picture, self.picture, mask=result.mask)
                # cv2.imshow("1",result.mask)
                # cv2.imshow("2",self.picture)
                # cv2.imshow("3",img2_fg)
                # cv2.waitKey(0)
                cv2.imwrite(os.path.join(r"D:\data\jx_cls\maskkou",os.path.basename(self.cameraInfo.fileName1)),img2_fg)
            # cv2.imwrite("sample/mask.jpeg",self.mask)
            # for roi in self.roiStruct:
            #     if self.logicModelName in roi.labels:
            #         x, y, w, h = cv2.boundingRect(roi.roi[0])
            #         area_roi = w*h
            #         for result in self.logicResult:
            #             result.mask = np.zeros_like(result.mask)
            #             mask = result.mask[y:y + h, x:x + w]
            #             # 二值化处理
            #             # _, threshold = cv2.threshold(result.mask, 127, 255, cv2.THRESH_BINARY)
            #             # 寻找最外面的轮廓
            #             contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            #             area_obj = 0
            #             t = np.zeros_like(mask)
            #             cv2.drawContours(t, contours, -1, (255), 2)
            #
            #             for contour in contours:
            #                 area_obj += cv2.contourArea(contour)
            #             # 目标轮廓面积 / roi面积区域
            #             area_obj_pro = area_obj / area_roi
            #             if area_obj_pro > cfg.logicModelDict[self.logicModelName]["param"]["proportion"]:
            #                 result.classname = "Proportion-fumo"
            #                 result.parames_vector = {"other_info": {'proportion': area_obj_pro}}
            #                 return_list.append(result)
            return return_list, []

        except Exception as e:
            logger.error(f"{self.logicModelName} {e}")
            logger.error(e.__traceback__.tb_frame.f_globals["__file__"])
            logger.error(e.__traceback__.tb_lineno)

        return [], []
